% PlotSTA.m

clear; clc; close all;
ii = 1; %Trial number
cd([RVLMTrials(ii).Reanalysis_folder,'/STA']);
load('StimTriggerAvg_v06Jun.mat')

%% Wave with stimuli labeled:
cd(RVLMTrials(ii).folder)
wavefile = dir('*_puff_wave.h5');
wave = h5read(wavefile.name,'/wave'); % space x time (samples)
wave_t = TrigAvg.wave_t;
if TrigAvg.puffStartFrame > 0
    wave(:,1:(TrigAvg.puffStartFrame-1)) = [];
end
fig = figure;
plot(wave_t,mean(wave,1),'k');
xline(0:TrigAvg.Period:(TrigAvg.Period*(nstim)))
%Bar for stimulus
ax = gca;
ylim_low = (ax.YLim(2) - ax.YLim(1)) * 0.05 + ax.YLim(1);
x = [0,2]; y = [ylim_low, ylim_low + ylim_low/50];
barLength = 2;  % 10% of x-axis width
yPos = y(1);
for jj = 1:(nstim+1)
    xStart = x(2) - barLength + TrigAvg.Period*(jj-1);
    line([xStart, xStart + barLength], [yPos, yPos], 'Color', 'r', 'LineWidth', 2);
end
xlabel('Time (s)','Interpreter','latex');
ylabel('dF/F','Interpreter','latex');
title({'Cortex-wide SMCGCaMP8.1 signal'},'Interpreter','latex');
ax.TickLabelInterpreter = 'latex';
cd([RVLMTrials(ii).Reanalysis_folder,'/STA']);
savestr = [extractBefore(RVLMTrials(ii).name,'_Parameters'),'_CtxAvgSignal'];
cd(saveloc);
fun_saveEPS(fig,savestr)
saveas(fig,[savestr,'.png'])
savefig(fig,[savestr,'.fig'])

%% Map of peak time.
seg_trace = TrigAvg.seg_meantrace;
t_ref = TrigAvg.t_ref;
minval_seg = NaN(size(seg_trace,1),1);
minind_seg = NaN(size(seg_trace,1),1);
mint_seg = NaN(size(seg_trace,1),1);
for jj = 1:size(seg_trace,1)
    [minval_seg(jj),minind_seg(jj)] = min(seg_trace(jj,:));
    mint_seg(jj) = t_ref(minind_seg(jj));
end

cd(RVLMTrials(ii).folder)
toplotfile = dir('*_puff.mat');
load(toplotfile.name,'toplot');
[mag] = fun_GetMagnification();
if strcmp(mag,'1')
    pix_mm = 92.8;
elseif strcmp(mag,'1.25')
    pix_mm = 115.0;
end
cmap = colormap('jet');
[fig] = fun_plotRGBmaps(mint_seg(toplot.skel_label),0,5,toplot,pix_mm,cmap); %pix_mm is 115 for 1.25x mag
cb = colorbar(); 
ylabel(cb,'Time at dilation peak (s)','FontSize',12,'Rotation',270,'Interpreter','latex')
title('Time at dilation peak, stimulus triggered average','FontSize',12,'Interpreter','latex');
savestr = [extractBefore(RVLMTrials(ii).name,'_Parameters'),'_DilationPkTime'];
cd(saveloc);
fun_saveEPS(fig,savestr)
saveas(fig,[savestr,'.png'])
savefig(fig,[savestr,'.fig'])

%% Map of peak dF/F.
[fig2] = fun_plotRGBmaps(minval_seg(toplot.skel_label),-0.03,0,toplot,pix_mm,cmap);
cb = colorbar(); 
ylabel(cb,'dF/F at peak dilation','FontSize',12,'Rotation',270,'Interpreter','latex')
title('dF/F at peak dilation, stimulus triggered average','FontSize',12,'Interpreter','latex');
savestr = [extractBefore(RVLMTrials(ii).name,'_Parameters'),'_DilationPkdF'];
cd(saveloc);
fun_saveEPS(fig2,savestr)
saveas(fig2,[savestr,'.png'])
savefig(fig2,[savestr,'.fig'])
