% fun_saveEPS.m

% Save after removing unnecessary lines from the eps file. These lines make
% loading extremely long and can crash illustrator...

function [] = fun_saveEPS(fig,savestr)

tot_save = [savestr,'.eps'];

print(fig,tot_save,'-depsc2', '-r300', '-loose');

fid = fopen(tot_save, 'r');
if fid == -1
    error('Could not open EPS file.');
end
file_contents = textscan(fid, '%s', 'Delimiter', '\n', 'Whitespace', '');
file_contents = string(file_contents{1});
fclose(fid);

start_marker = "%FOPBeginFontReencode"; %Might be able to remove more sections. 
end_marker = "%FOPEndFontReencode";    
% Find indices of the markers
start_idx = find(file_contents == start_marker, 1);
end_idx = find(file_contents == end_marker, 1, 'last'); % Last occurrence

file_contents(start_idx:end_idx) = [];  % Remove lines in between

% Write cleaned EPS to a new file
fid = fopen(tot_save, 'w');
if fid == -1
    error('Could not create output EPS file. fid = -1');
end
fprintf(fid, '%s\n', file_contents);
fclose(fid);

disp(['Cleaned EPS saved as: ', tot_save]);

end

