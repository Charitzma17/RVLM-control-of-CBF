% fun_StimTrigAverage.m

function [t_ref,intp_tracemat] = fun_StimTrigAverage(trace,nstim,time,period)

tmat = NaN(nstim,100);
dmat = NaN(nstim,100);
t_start = zeros(nstim,1);
t_end = zeros(nstim,1);

for ii = 1:nstim
    is_t = time > (ii-1)*period & time < ii*period;
    tmat(ii,1:length(find(is_t))) = time(is_t);
    dmat(ii,1:length(find(is_t))) = trace(is_t);
    t_start(ii) = tmat(ii,1) - (ii-1)*period;
    t_end(ii) = tmat(ii,length(find(is_t))) - (ii-1)*period;
end

max_start = max(t_start);
min_end = min(t_end);

%Interpolate data to a common time series.
t_ref = max_start:0.1:min_end;
intp_tracemat = NaN(nstim,length(t_ref));
for ii = 1:nstim
    numpts = sum(~isnan(dmat(ii,:)));
    intp_tracemat(ii,:) = interp1(tmat(ii,1:numpts) - period*(ii-1),dmat(ii,1:numpts),t_ref);
end

end