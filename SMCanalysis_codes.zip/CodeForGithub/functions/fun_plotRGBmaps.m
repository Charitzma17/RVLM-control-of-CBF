
% fun_plotRGBmaps.m

function [fig] = fun_plotRGBmaps(plot_input,plt_min,plt_max,toplot,pix_mm,cmap)


im_size = toplot.mask_size;
map = zeros(im_size);

map(toplot.mask_ind) = plot_input;

rescaled_pwr = nan(toplot.mask_size);
tmp_pixel_value = map(toplot.mask_ind);
rescaled_pwr(toplot.mask_ind) = tmp_pixel_value;

int_to_cmap = linspace(plt_min, plt_max, size(cmap,1));
non_nan_ind = find(map);
num_nonnan = numel(non_nan_ind);
rbg_pwr_list = zeros(num_nonnan, 3);
if num_nonnan > 0
    rbg_pwr_list(:, 1) = interp1(int_to_cmap, cmap(:, 1), rescaled_pwr(non_nan_ind));
    rbg_pwr_list(:, 2) = interp1(int_to_cmap, cmap(:, 2), rescaled_pwr(non_nan_ind));
    rbg_pwr_list(:, 3) = interp1(int_to_cmap, cmap(:, 3), rescaled_pwr(non_nan_ind));
end
rgb_pwr = ones(3, prod(im_size)) * 0.5;
if num_nonnan > 0
    rgb_pwr(:, non_nan_ind) = rbg_pwr_list.';
end
% rgb_pwr(:, NotSig_mask_ind) = 0.4;
rgb_pwr = reshape(rgb_pwr, 3, im_size(1), im_size(2));
clear i j pixcolor cmap int_to_cmap
fig = figure();
imagesc(flip(permute(rgb_pwr, [3, 2, 1]),2));
axis off;
box off;
colormap jet;

clim([plt_min plt_max]);
daspect([1,1,1]);
colorbar;

%Add scalebar
hold on;
sbsz = pix_mm*1;
sbx = (1:(sbsz)) + 30;
sby = repmat(im_size(2)-30,1,length(sbx));
plot(sbx,sby,'k')


end