% fun_GetMagnification.m

function [mag] = fun_GetMagnification()

    paramFile = dir('*Parameters.mat');
    load(paramFile.name,'recprams');
    mag = recprams.magnification;

end