% ProcessSMCCaStimTrigAvg.m

%% Calculate acquisition - stim timing
ii = 1;
data_folder = Trials(ii).folder; % List of experiments, result of dir.
cd(data_folder);

%LOAD TOPLOT / SENSOR DATA
testfile = dir('*_puff.mat'); 
load(testfile(1).name); % Load frame and stim triggers (SensorData)

%Get true first frame of the stim:
p95 = SensorData.p95b;
stim = SensorData.stimLED;
[~,stimidx] = findpeaks(diff(stim),'MinPeakHeight',1);
tmp_start = stimidx(1); %The NI sample number immediately before the first sitm peak.
%Get the idx of each prime frame:
[~,p95idx] = findpeaks(diff(p95),'MinPeakHeight',1);

%Consistiency check:
num_p95Trigs = numel(p95idx);
cd(data_folder);
ims_test = dir(fun_LinuxPath('*\*_z000.tif')); % All camera images
if isempty(ims_test)
    ims_test = dir(fun_LinuxPath('**\img_*_Default_000.tif')); % All camera images
end
todel = [ims_test(:).isdir];
if sum(todel) > 0
    ims_test(todel) = [];
    disp(['Deleted ',num2str(sum(todel)),' entries from ims_test'])
end
num_ims = length(ims_test);
if ~isequal(num_ims,num_p95Trigs)
    disp('p95 triggers NOT equal to number of images')
    pause();
else
    disp('p95 triggers ARE equal to number of images')
end

%WHICH FRAME DID THE STIM START ON
sigdiff = p95idx - tmp_start;
finddiff = find(sigdiff >= 0);
frame_post_stim = finddiff(1) %This frame is at or after the first stim event.

%WHICH FRAME DID WE ANALYZE AS THE FIRST STIMULATED FRAME
firstfr = round(tmp_start * 0.001 * toplot.rate)
firstfrVes = firstfr;

frame_post_stim_t = p95idx(frame_post_stim);
firstfrVes_t = p95idx(firstfrVes);


%% Load and trim SMC Ca dF/F traces

wavefile = dir('*_puff_wave.h5');
puffwave = h5read(wavefile.name,'/wave');

period = (1/toplot.f_peak(2)); % Seconds
%Define first time point as zero seconds
wave_t = (p95idx(firstfrVes:(firstfrVes + size(puffwave,2) - 1))); %Samples
wave_t = wave_t - tmp_start; %Now zero is exactly on the first stim.

% Trim wave to perform the stim-triggered average:
if wave_t(1) > 0 % Analyzed trace starts after the first stim
    second_stim = period * 1000;
    todel = wave_t < second_stim;
    puffwave(:,todel) = [];
    wave_t(todel) = [];
    wave_t = wave_t - second_stim;
    puffStartFrame = sum(todel) + 1;
elseif wave_t(1) < 0 % Analyzed trace starts before the first stim 
    todel = wave_t < 0;
    puffwave(:,todel) = [];
    wave_t(todel) = [];
    puffStartFrame = sum(todel) + 1;
elseif wave_t(1) == 0
    puffStartFrame = 1;
end
wave_t = wave_t / 1000; %Seconds


%% Calculate stimulus triggered average and save

[~,duty_stimidx] = findpeaks(diff(stim),'MinPeakHeight',1,'MinPeakDistance',(period - 1)*1000);
nstim = length(duty_stimidx);
if exist('second_stim', 'var')
    nstim = nstim - 2; % Subtract 1 for the ignored first stim, 1 b/c we don't want to analyze the last stim.
else
    nstim = nstim - 1; % Subtract 1 b/c we don't want to analyze the last stim.
end
% Stimulus triggered average for the cortex-average signal
wave_ctxAvg = mean(puffwave); % Average over space (first dimension)
[t_ref,allctx_tracemat] = fun_StimTrigAverage(wave_ctxAvg,nstim,wave_t,period);

% Stimulus triggered average for every segment
seg_meantrace = NaN(size(puffwave,1),size(t_ref,2));
for jj = 1:size(puffwave,1)
    [~,intp_tracemat] = fun_StimTrigAverage(puffwave(jj,:),nstim,wave_t,period);
    seg_meantrace(jj,:) = mean(intp_tracemat);
end


%%

TrigAvg = struct();
TrigAvg.puffStartFrame = puffStartFrame;
TrigAvg.nstim = nstim;
TrigAvg.Period = period;
TrigAvg.duty_stimidx = duty_stimidx;
TrigAvg.wave_t = wave_t;
TrigAvg.t_ref = t_ref;
TrigAvg.allctx_tracemat = allctx_tracemat;
% For segment wise trigger average:
TrigAvg.seg_meantrace = seg_meantrace;

%Save
cd(Trials(ii).Reanalysis_folder)
if isfolder('STA')
    cd('STA')
    save('StimTriggerAvg_v06Jun.mat','TrigAvg');
else
    mkdir('STA')
    cd('STA')
    save('StimTriggerAvg_v06Jun.mat','TrigAvg');
end







